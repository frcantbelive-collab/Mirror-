package com.mirrorkeys.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.AttributeSet
import android.util.SparseArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.mirrorkeys.Prefs
import com.mirrorkeys.modes.InputMode
import com.mirrorkeys.modes.ModeState
import com.mirrorkeys.modes.NormalMode
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

interface KeyboardActions {
    fun onKey(text: String)
    fun onSpace()
    fun onBackspace()
    fun onBackspaceWord()
    fun onEnter()
    fun onModeChanged()
    fun onLanguageChanged()
}

private class KRect(val key: Key, val rect: RectF, val cell: RectF) {
    val press = Spring(0f, 0f, 900f, 34f)
    val appear = Spring(1f, 1f, 380f, 22f)
    var delayNs = 0L
    var rippleStart = 0L
    var rippleX = 0f
    var rippleY = 0f
}

private class Touch(val id: Int) {
    var kr: KRect? = null
    var downX = 0f
    var downY = 0f
    var x = 0f
    var y = 0f
    var anchorX = 0f
    var region = 0 // 0 клавиши, 1 панель режимов, 2 выбор режима, 3 ничего
    var popup = false
    var done = false
    var opener = false
    var wordMode = false
    var repeatCount = 0
    var longRunnable: Runnable? = null
    var repeatRunnable: Runnable? = null
}

class KeyboardView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    View(context, attrs) {

    var actions: KeyboardActions? = null

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density

    private var theme: KeyTheme = Themes.get(Prefs.theme)
    private var lang: Int = Prefs.lang
    private var pageId = 0
    private var heightScale = Prefs.heightPct / 100f
    private var corner = Prefs.cornerPct / 100f
    private var shift = 0 // 0 выкл, 1 один раз, 2 caps
    private var autoShift = false
    private var lastShiftTap = 0L
    private var plain = false
    private var previewRaw = ""
    private var previewRendered = ""

    private val keys = ArrayList<KRect>()
    private val touches = SparseArray<Touch>()
    private val ui = Handler(Looper.getMainLooper())
    private val rf = RectF()
    private val path = Path()
    private val shaderMatrix = Matrix()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val typeReg: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val typeMed: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    private var keyShader: LinearGradient? = null
    private var spShader: LinearGradient? = null
    private var accShader: LinearGradient? = null
    private var hiShader: LinearGradient? = null
    private var bgShader: LinearGradient? = null

    // акцент режима и волна
    private var accFrom = ModeState.current().accent
    private var accTo = accFrom
    private var accentShown = accFrom
    private val accT = Spring(1f, 1f, 90f, 16f)
    private var builtT = -1f
    private var waveStart = 0L
    private var waveX = 0f
    private var waveY = 0f

    // пружины интерфейса
    private val barPress = Spring(0f, 0f, 700f, 30f)
    private val pickerT = Spring(0f, 0f, 260f, 24f)
    private val bubScale = Spring(0f, 0f, 700f, 32f)
    private val bubX = Spring(0f, 0f, 650f, 34f)
    private val bubY = Spring(0f, 0f, 650f, 34f)
    private var bubbleLabel = ""

    // всплывающие варианты
    private var popupOpen = false
    private var popupKr: KRect? = null
    private var popupItems: List<String> = emptyList()
    private var popupSel = 0
    private var popLeft = 0f
    private var popIw = 0f

    // выбор режима
    private var pickerOpen = false
    private var pickerHover = -1

    private var lastNs = 0L

    // ───────────── геометрия ─────────────
    private fun barH() = dp(44f)
    private fun prevH() = dp(22f)
    private fun keyH() = dp(50f) * heightScale
    private fun rowGap() = dp(6f)
    private fun keysTop() = barH() + prevH() + dp(5f)
    private fun keysBottom() = keysTop() + 4 * keyH() + 3 * rowGap()
    private fun totalH() = keysBottom() + dp(8f)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), totalH().roundToInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        buildLayout(false)
        rebuildShaders()
    }

    private fun currentPage(): Page = Layouts.page(lang, pageId)

    private fun buildLayout(stagger: Boolean) {
        keys.clear()
        val w = width.toFloat()
        if (w <= 0f) return
        val page = currentPage()
        val side = dp(3f)
        val gap = dp(6f)
        val kh = keyH()
        val now = System.nanoTime()
        var n = 0
        for (ri in page.rows.indices) {
            val row = page.rows[ri]
            var total = 0f
            for (k in row) total += k.weight
            val unit = (w - 2f * side) / total
            var x = side
            val y = keysTop() + ri * (kh + rowGap())
            for (k in row) {
                val cw = k.weight * unit
                if (k.type != KeyType.GAP) {
                    val rect = RectF(x + gap / 2f, y, x + cw - gap / 2f, y + kh)
                    val cell = RectF(x, y - rowGap() / 2f, x + cw, y + kh + rowGap() / 2f)
                    val kr = KRect(k, rect, cell)
                    if (stagger) {
                        kr.appear.snap(0f)
                        kr.appear.target = 1f
                        kr.delayNs = now + n * 5_000_000L
                    }
                    keys.add(kr)
                    n++
                }
            }
        }
        invalidate()
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt().coerceIn(0, 255)
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt().coerceIn(0, 255)
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, bl)
    }

    private fun rebuildShaders() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val a = accentShown
        val kh = keyH()
        keyShader = LinearGradient(
            0f, 0f, 0f, kh,
            mix(theme.key1, a, 0.10f), mix(theme.key2, a, 0.16f), Shader.TileMode.CLAMP
        )
        spShader = LinearGradient(
            0f, 0f, 0f, kh,
            mix(theme.sp1, a, 0.06f), mix(theme.sp2, a, 0.10f), Shader.TileMode.CLAMP
        )
        accShader = LinearGradient(
            0f, 0f, 0f, kh,
            mix(a, Color.WHITE, 0.18f), mix(a, Color.BLACK, 0.12f), Shader.TileMode.CLAMP
        )
        val hiTop = if (theme.dark) Color.argb(70, 255, 255, 255) else Color.argb(235, 255, 255, 255)
        hiShader = LinearGradient(
            0f, 0f, 0f, kh,
            intArrayOf(hiTop, Color.argb(0, 255, 255, 255)), floatArrayOf(0f, 0.6f),
            Shader.TileMode.CLAMP
        )
        bgShader = LinearGradient(
            0f, 0f, w * 0.5f, h,
            mix(theme.bg1, a, 0.10f), mix(theme.bg2, a, 0.20f), Shader.TileMode.CLAMP
        )
        builtT = accT.value
    }

    // ───────────── публичный API ─────────────
    fun applyPrefs() {
        val t = Themes.get(Prefs.theme)
        val hs = Prefs.heightPct / 100f
        val cr = Prefs.cornerPct / 100f
        val changed = t !== theme || hs != heightScale || cr != corner
        if (!changed) return
        val relayout = hs != heightScale
        theme = t
        heightScale = hs
        corner = cr
        if (relayout) requestLayout()
        buildLayout(false)
        rebuildShaders()
        invalidate()
    }

    fun setPlain(p: Boolean) {
        plain = p
        previewRendered = if (previewRaw.isEmpty()) "" else currentMode().render(previewRaw)
        invalidate()
    }

    fun setPreview(raw: String) {
        previewRaw = raw
        previewRendered = if (raw.isEmpty()) "" else currentMode().render(raw)
        invalidate()
    }

    fun setAutoShift(on: Boolean) {
        if (on && shift == 0 && currentPage().letters) {
            shift = 1
            autoShift = true
            invalidate()
        } else if (!on && autoShift && shift == 1) {
            shift = 0
            autoShift = false
            invalidate()
        }
    }

    fun setPageForInput(numeric: Boolean) {
        val target = if (numeric) 1 else 0
        if (pageId != target) {
            pageId = target
            buildLayout(false)
        }
    }

    private fun currentMode(): InputMode = if (plain) NormalMode else ModeState.current()

    private fun display(kr: KRect): String {
        val l = kr.key.label
        return if (kr.key.type == KeyType.CHAR && shift != 0 && currentPage().letters) l.uppercase() else l
    }

    private fun consumeShift() {
        if (shift == 1) {
            shift = 0
            autoShift = false
        }
    }

    private fun haptic() {
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    // ───────────── рисование ─────────────
    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        var dt = if (lastNs == 0L) 0.016f else (now - lastNs) / 1e9f
        if (dt > 0.05f) dt = 0.05f
        lastNs = now
        var more = false
        val w = width.toFloat()
        val h = height.toFloat()

        accT.step(dt)
        if (accT.active) more = true
        accentShown = mix(accFrom, accTo, accT.value.coerceIn(0f, 1f))
        if (accT.value != builtT || bgShader == null) rebuildShaders()

        for (s in arrayOf(barPress, pickerT, bubScale, bubX, bubY)) {
            s.step(dt)
            if (s.active) more = true
        }

        // фон
        bgPaint.shader = bgShader
        c.drawRect(0f, 0f, w, h, bgPaint)

        drawBar(c)
        drawPreview(c)

        for (kr in keys) {
            if (now >= kr.delayNs) kr.appear.step(dt)
            kr.press.step(dt)
            if (kr.appear.active || kr.press.active || now < kr.delayNs) more = true
            if (kr.rippleStart != 0L && (now - kr.rippleStart) / 1_000_000L < 380L) more = true
            drawKey(c, kr, now)
        }

        if (popupOpen) drawPopup(c)
        drawBubble(c)
        if (pickerOpen || pickerT.value > 0.01f) drawPicker(c)

        // волна цвета режима
        if (waveStart != 0L) {
            val el = (now - waveStart) / 1e6f
            if (el < 700f) {
                more = true
                val t = el / 700f
                val e = 1f - (1f - t) * (1f - t) * (1f - t)
                val rad = max(1f, e * hypot(w, h) * 1.05f)
                val a = ((1f - t) * 0.5f * 255f).toInt().coerceIn(0, 255)
                val rgb = accTo and 0x00FFFFFF
                val edge = rgb or (a shl 24)
                val inner = rgb
                wavePaint.shader = RadialGradient(
                    waveX, waveY, rad, intArrayOf(inner, inner, edge),
                    floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP
                )
                c.drawCircle(waveX, waveY, rad, wavePaint)
                wavePaint.shader = null
            } else {
                waveStart = 0L
            }
        }

        if (more) postInvalidateOnAnimation()
    }

    private fun setText(size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER, tf: Typeface = typeReg) {
        textPaint.shader = null
        textPaint.style = Paint.Style.FILL
        textPaint.textSize = size
        textPaint.color = color
        textPaint.textAlign = align
        textPaint.typeface = tf
    }

    private fun drawBar(c: Canvas) {
        val m = currentMode()
        val cy = barH() / 2f
        val bx = dp(8f) + dp(17f)
        val sc = 1f - 0.10f * barPress.value
        val base = if (plain) theme.dim else accentShown
        c.save()
        c.scale(sc, sc, bx, cy)
        fillPaint.shader = null
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = base
        fillPaint.alpha = 55
        c.drawCircle(bx, cy, dp(21f), fillPaint)
        fillPaint.color = base
        c.drawCircle(bx, cy, dp(17f), fillPaint)
        Icons.drawModeIcon(c, bx, cy, dp(8.5f), m.icon, Color.WHITE, textPaint)
        c.restore()

        val title = if (plain) "Режимы выключены в этом поле" else m.title
        setText(dp(14f), if (plain) theme.dim else theme.text, Paint.Align.LEFT, typeMed)
        val ty = cy - (textPaint.descent() + textPaint.ascent()) / 2f
        c.drawText(title, bx + dp(26f), ty, textPaint)

        if (!plain) {
            val n = ModeState.count()
            val cur = ModeState.index()
            val step = dp(7.5f)
            var x = width - dp(12f) - n * step + step / 2f
            for (i in 0 until n) {
                fillPaint.style = Paint.Style.FILL
                if (i == cur) {
                    fillPaint.color = accentShown
                    rf.set(x - dp(4.5f), cy - dp(2.3f), x + dp(4.5f), cy + dp(2.3f))
                    c.drawRoundRect(rf, dp(2.3f), dp(2.3f), fillPaint)
                } else {
                    fillPaint.color = theme.dim
                    fillPaint.alpha = 110
                    c.drawCircle(x, cy, dp(1.8f), fillPaint)
                }
                x += step
            }
        }
    }

    private fun drawPreview(c: Canvas) {
        val l = dp(10f)
        val r = width - dp(10f)
        rf.set(l, barH(), r, barH() + prevH() - dp(2f))
        fillPaint.shader = null
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = theme.text
        fillPaint.alpha = if (theme.dark) 20 else 14
        c.drawRoundRect(rf, dp(8f), dp(8f), fillPaint)

        val m = currentMode()
        val s: String
        val color: Int
        if (plain) {
            s = "Поле пароля, почты, ссылки или поиска"
            color = theme.dim
        } else if (previewRaw.isEmpty()) {
            s = m.title + ":  " + m.render("Hello World")
            color = theme.dim
        } else {
            s = previewRendered
            color = accentShown
        }
        setText(dp(13f), color, Paint.Align.LEFT, typeMed)
        val maxW = r - l - dp(16f)
        val n = textPaint.breakText(s, false, maxW, null)
        val shown = if (n >= s.length) s else s.substring(s.length - n)
        val cy = rf.centerY()
        val ty = cy - (textPaint.descent() + textPaint.ascent()) / 2f
        c.drawText(shown, l + dp(8f), ty, textPaint)
    }

    private fun drawKey(c: Canvas, kr: KRect, now: Long) {
        val r = kr.rect
        val kh = keyH()
        val p = kr.press.value.coerceIn(0f, 1.15f)
        val ap = kr.appear.value.coerceIn(0f, 1.2f)
        val sc = (0.86f + 0.14f * ap) * (1f - 0.06f * p)
        val radius = kh * (0.10f + 0.40f * corner)
        val type = kr.key.type

        c.save()
        c.scale(sc, sc, r.centerX(), r.centerY())

        // тень
        val off = dp(2.4f) * (1f - 0.75f * p)
        shadowPaint.style = Paint.Style.FILL
        shadowPaint.color = theme.shadow
        shadowPaint.alpha = if (theme.dark) 70 else 40
        rf.set(r.left, r.top + off * 1.8f, r.right, r.bottom + off * 1.8f)
        c.drawRoundRect(rf, radius, radius, shadowPaint)
        shadowPaint.alpha = if (theme.dark) 90 else 55
        rf.set(r.left, r.top + off, r.right, r.bottom + off)
        c.drawRoundRect(rf, radius, radius, shadowPaint)

        // тело
        val shiftOn = type == KeyType.SHIFT && shift != 0
        val sh: LinearGradient? = when {
            type == KeyType.ENTER || shiftOn -> accShader
            type == KeyType.CHAR || type == KeyType.SPACE -> keyShader
            else -> spShader
        }
        shaderMatrix.setTranslate(0f, r.top)
        sh?.setLocalMatrix(shaderMatrix)
        keyPaint.shader = sh
        c.drawRoundRect(r, radius, radius, keyPaint)

        // нажатие: окрашивание
        if (p > 0.01f) {
            fillPaint.shader = null
            fillPaint.style = Paint.Style.FILL
            fillPaint.color = accentShown
            fillPaint.alpha = (70f * p).toInt().coerceIn(0, 255)
            c.drawRoundRect(r, radius, radius, fillPaint)
        }

        // подсветка верхней грани
        hiShader?.setLocalMatrix(shaderMatrix)
        hiPaint.shader = hiShader
        hiPaint.strokeWidth = dp(1f)
        rf.set(r.left + dp(0.5f), r.top + dp(0.5f), r.right - dp(0.5f), r.bottom - dp(0.5f))
        c.drawRoundRect(rf, radius, radius, hiPaint)

        // ripple
        if (kr.rippleStart != 0L) {
            val el = (now - kr.rippleStart) / 1e6f
            if (el < 380f) {
                val t = el / 380f
                val e = 1f - (1f - t) * (1f - t) * (1f - t)
                path.reset()
                path.addRoundRect(r, radius, radius, Path.Direction.CW)
                c.save()
                c.clipPath(path)
                fillPaint.shader = null
                fillPaint.style = Paint.Style.FILL
                fillPaint.color = if (theme.dark) Color.WHITE else accentShown
                fillPaint.alpha = ((1f - t) * 110f).toInt().coerceIn(0, 255)
                c.drawCircle(kr.rippleX, kr.rippleY, max(r.width(), r.height()) * 0.95f * e, fillPaint)
                c.restore()
            }
        }

        // содержимое
        val cx = r.centerX()
        val cy = r.centerY()
        val s = kh * 0.19f
        when (type) {
            KeyType.CHAR -> {
                setText(kh * 0.40f, theme.text, Paint.Align.CENTER, typeReg)
                val ty = cy - (textPaint.descent() + textPaint.ascent()) / 2f
                c.drawText(display(kr), cx, ty, textPaint)
                if (kr.key.alts.isNotEmpty()) {
                    val hint = kr.key.alts.substring(0, 1)
                    setText(kh * 0.22f, theme.dim, Paint.Align.RIGHT, typeReg)
                    c.drawText(hint, r.right - dp(5f), r.top + kh * 0.22f + dp(3f), textPaint)
                }
            }
            KeyType.SPACE -> {
                val m = currentMode()
                val name = if (lang == 0) "Русский" else "English"
                val label = if (plain || m === NormalMode) name else name + " · " + m.title
                setText(dp(12f), theme.dim, Paint.Align.CENTER, typeMed)
                val ty = cy - (textPaint.descent() + textPaint.ascent()) / 2f
                c.drawText(label, cx, ty, textPaint)
            }
            KeyType.SHIFT -> {
                val col = if (shiftOn) Color.WHITE else theme.text
                Icons.drawShift(c, cx, cy - (if (shift == 2) dp(1.5f) else 0f), s, iconPaint, shiftOn, col)
                if (shift == 2) {
                    iconPaint.style = Paint.Style.STROKE
                    iconPaint.color = Color.WHITE
                    iconPaint.strokeWidth = s * 0.2f
                    c.drawLine(cx - s * 0.5f, cy + s * 1.25f, cx + s * 0.5f, cy + s * 1.25f, iconPaint)
                }
            }
            KeyType.DEL -> Icons.drawBackspace(c, cx, cy, s, iconPaint, theme.text)
            KeyType.ENTER -> Icons.drawEnter(c, cx, cy, s, iconPaint, Color.WHITE)
            KeyType.LANG -> Icons.drawGlobe(c, cx, cy, s * 0.95f, iconPaint, theme.text)
            KeyType.TO_SYM -> labelKey(c, "?123", cx, cy)
            KeyType.TO_ABC -> labelKey(c, if (lang == 0) "АБВ" else "ABC", cx, cy)
            KeyType.TO_SYM2 -> labelKey(c, "=\\<", cx, cy)
            KeyType.TO_SYM1 -> labelKey(c, "?123", cx, cy)
            KeyType.GAP -> {}
        }
        c.restore()
    }

    private fun labelKey(c: Canvas, s: String, cx: Float, cy: Float) {
        setText(dp(14f), theme.text, Paint.Align.CENTER, typeMed)
        val ty = cy - (textPaint.descent() + textPaint.ascent()) / 2f
        c.drawText(s, cx, ty, textPaint)
    }

    private fun drawBubble(c: Canvas) {
        val sc = bubScale.value
        if (sc <= 0.02f || bubbleLabel.isEmpty() || popupOpen) return
        val bw = dp(56f)
        val bh = dp(64f)
        val cx = bubX.value.coerceIn(bw / 2f + dp(4f), width - bw / 2f - dp(4f))
        val bottom = bubY.value
        c.save()
        c.scale(sc, sc, cx, bottom)
        rf.set(cx - bw / 2f, bottom - bh, cx + bw / 2f, bottom)
        shadowPaint.style = Paint.Style.FILL
        shadowPaint.color = theme.shadow
        shadowPaint.alpha = 80
        rf.offset(0f, dp(2f))
        c.drawRoundRect(rf, dp(16f), dp(16f), shadowPaint)
        rf.offset(0f, -dp(2f))
        fillPaint.shader = null
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = mix(theme.key1, accentShown, if (theme.dark) 0.35f else 0.18f)
        c.drawRoundRect(rf, dp(16f), dp(16f), fillPaint)
        hiPaint.shader = null
        hiPaint.color = Color.argb(if (theme.dark) 90 else 200, 255, 255, 255)
        hiPaint.strokeWidth = dp(1f)
        c.drawRoundRect(rf, dp(16f), dp(16f), hiPaint)
        setText(dp(30f), theme.text, Paint.Align.CENTER, typeReg)
        val ty = rf.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f
        c.drawText(bubbleLabel, cx, ty, textPaint)
        c.restore()
    }

    private fun drawPopup(c: Canvas) {
        val kr = popupKr ?: return
        val n = popupItems.size
        if (n == 0) return
        val ph = keyH() * 1.1f
        val bottom = kr.rect.top - dp(6f)
        rf.set(popLeft, bottom - ph, popLeft + popIw * n, bottom)
        fillPaint.shader = null
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = mix(theme.key1, accentShown, if (theme.dark) 0.30f else 0.12f)
        c.drawRoundRect(rf, dp(14f), dp(14f), fillPaint)
        for (i in 0 until n) {
            val x0 = popLeft + popIw * i
            if (i == popupSel) {
                fillPaint.color = accentShown
                rf.set(x0 + dp(3f), bottom - ph + dp(3f), x0 + popIw - dp(3f), bottom - dp(3f))
                c.drawRoundRect(rf, dp(11f), dp(11f), fillPaint)
            }
            setText(keyH() * 0.46f, if (i == popupSel) Color.WHITE else theme.text, Paint.Align.CENTER, typeReg)
            val ty = bottom - ph / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
            c.drawText(popupItems[i], x0 + popIw / 2f, ty, textPaint)
        }
    }

    private fun drawPicker(c: Canvas) {
        val t = pickerT.value.coerceIn(0f, 1f)
        val n = ModeState.count()
        val cols = 5
        val rows = (n + cols - 1) / cols
        val top = barH()
        val cw = width / cols.toFloat()
        val chh = (height - top) / rows
        fillPaint.shader = null
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = mix(theme.bg1, Color.BLACK, if (theme.dark) 0.25f else 0f)
        fillPaint.alpha = (245f * t).toInt().coerceIn(0, 255)
        c.drawRect(0f, top, width.toFloat(), height.toFloat(), fillPaint)
        val cur = ModeState.index()
        for (i in 0 until n) {
            val m = com.mirrorkeys.modes.ModeRegistry.all[i]
            val col = i % cols
            val row = i / cols
            val cx = cw * col + cw / 2f
            val cy = top + chh * row + chh * 0.40f
            val rad = min(cw, chh) * 0.30f
            val hot = i == pickerHover
            val sc = (0.7f + 0.3f * t) * (if (hot) 1.12f else 1f)
            c.save()
            c.scale(sc, sc, cx, cy)
            fillPaint.color = m.accent
            fillPaint.alpha = (255f * t).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, rad, fillPaint)
            if (i == cur || hot) {
                iconPaint.shader = null
                iconPaint.style = Paint.Style.STROKE
                iconPaint.strokeWidth = dp(2f)
                iconPaint.color = theme.text
                iconPaint.alpha = (255f * t).toInt().coerceIn(0, 255)
                c.drawCircle(cx, cy, rad + dp(3f), iconPaint)
            }
            Icons.drawModeIcon(c, cx, cy, rad * 0.5f, m.icon, Color.WHITE, textPaint)
            c.restore()
            setText(dp(10f), theme.text, Paint.Align.CENTER, typeMed)
            textPaint.alpha = (255f * t).toInt().coerceIn(0, 255)
            val maxW = cw - dp(6f)
            val k = textPaint.breakText(m.title, true, maxW, null)
            c.drawText(m.title.substring(0, k), cx, cy + rad + dp(15f), textPaint)
        }
    }

    // ───────────── касания ─────────────
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                up(e.getPointerId(i), e.getX(i), e.getY(i), false)
            }
            MotionEvent.ACTION_CANCEL -> {
                val ids = ArrayList<Int>()
                for (i in 0 until touches.size()) ids.add(touches.keyAt(i))
                for (id in ids) up(id, 0f, 0f, true)
            }
        }
        return true
    }

    private fun hit(x: Float, y: Float): KRect? {
        val top = keysTop()
        val side = dp(3f)
        if (y < top - rowGap() / 2f) return null
        val yy = if (y > keysBottom()) keysBottom() - 1f else y
        val xx = x.coerceIn(side + 0.5f, width - side - 0.5f)
        for (kr in keys) {
            if (kr.cell.contains(xx, yy)) return kr
        }
        return null
    }

    private fun scheduleLong(t: Touch, delay: Long, action: () -> Unit) {
        cancelLong(t)
        val r = Runnable {
            t.longRunnable = null
            action()
        }
        t.longRunnable = r
        ui.postDelayed(r, delay)
    }

    private fun cancelLong(t: Touch) {
        t.longRunnable?.let { ui.removeCallbacks(it) }
        t.longRunnable = null
    }

    private fun scheduleRepeat(t: Touch, delay: Long) {
        cancelRepeat(t)
        val r = object : Runnable {
            override fun run() {
                if (t.wordMode) return
                actions?.onBackspace()
                haptic()
                t.repeatCount++
                val next = (110L - t.repeatCount * 7L).coerceAtLeast(30L)
                ui.postDelayed(this, next)
            }
        }
        t.repeatRunnable = r
        ui.postDelayed(r, delay)
    }

    private fun cancelRepeat(t: Touch) {
        t.repeatRunnable?.let { ui.removeCallbacks(it) }
        t.repeatRunnable = null
    }

    private fun down(id: Int, x: Float, y: Float) {
        val t = Touch(id)
        t.downX = x
        t.downY = y
        t.x = x
        t.y = y
        t.anchorX = x
        touches.put(id, t)

        if (pickerOpen) {
            t.region = 2
            pickerHover = pickerIndexAt(x, y)
            invalidate()
            return
        }
        if (y < barH()) {
            t.region = 1
            barPress.target = 1f
            if (!plain) scheduleLong(t, 450L) { openPicker(t) }
            invalidate()
            return
        }
        val kr = hit(x, y)
        if (kr == null) {
            t.region = 3
            return
        }
        t.region = 0
        t.kr = kr
        pressKey(t, kr, x, y)
    }

    private fun pressKey(t: Touch, kr: KRect, x: Float, y: Float) {
        kr.press.target = 1f
        kr.rippleStart = System.nanoTime()
        kr.rippleX = x
        kr.rippleY = y
        haptic()
        when (kr.key.type) {
            KeyType.CHAR -> {
                bubbleLabel = display(kr)
                bubX.snap(x)
                bubY.snap(kr.rect.top - dp(3f))
                bubScale.snap(0.35f)
                bubScale.target = 1f
                if (kr.key.alts.isNotEmpty()) scheduleLong(t, 380L) { openPopup(t, kr) }
            }
            KeyType.DEL -> {
                actions?.onBackspace()
                t.repeatCount = 0
                scheduleRepeat(t, 380L)
            }
            else -> {}
        }
        invalidate()
    }

    private fun openPopup(t: Touch, kr: KRect) {
        val items = ArrayList<String>()
        val up = shift != 0 && currentPage().letters
        for (ch in kr.key.alts) items.add(if (up) ch.toString().uppercase() else ch.toString())
        popupItems = items
        popupKr = kr
        popupOpen = true
        t.popup = true
        popIw = max(kr.rect.width(), dp(40f))
        val pw = popIw * items.size
        popLeft = (kr.rect.left - dp(2f)).coerceIn(dp(4f), max(dp(4f), width - pw - dp(4f)))
        popupSel = ((t.x - popLeft) / popIw).toInt().coerceIn(0, items.size - 1)
        bubScale.target = 0f
        haptic()
        invalidate()
    }

    private fun openPicker(t: Touch) {
        pickerOpen = true
        pickerT.target = 1f
        t.region = 2
        t.opener = true
        barPress.target = 0f
        pickerHover = pickerIndexAt(t.x, t.y)
        haptic()
        invalidate()
    }

    private fun closePicker() {
        pickerOpen = false
        pickerT.target = 0f
        pickerHover = -1
        invalidate()
    }

    private fun pickerIndexAt(x: Float, y: Float): Int {
        val n = ModeState.count()
        val cols = 5
        val rows = (n + cols - 1) / cols
        val top = barH()
        if (y < top) return -1
        val cw = width / cols.toFloat()
        val chh = (height - top) / rows
        val col = (x / cw).toInt().coerceIn(0, cols - 1)
        val row = ((y - top) / chh).toInt().coerceIn(0, rows - 1)
        val i = row * cols + col
        return if (i < n) i else -1
    }

    private fun move(id: Int, x: Float, y: Float) {
        val t = touches.get(id) ?: return
        t.x = x
        t.y = y
        when (t.region) {
            2 -> {
                val idx = pickerIndexAt(x, y)
                if (idx != pickerHover) {
                    pickerHover = idx
                    invalidate()
                }
            }
            1 -> {
                val dx = x - t.downX
                if (!t.done && abs(dx) > dp(48f)) {
                    t.done = true
                    cancelLong(t)
                    barPress.target = 0f
                    switchMode(if (dx < 0) 1 else -1, x, barH() / 2f)
                }
            }
            0 -> {
                val kr = t.kr ?: return
                if (t.popup) {
                    val n = popupItems.size
                    if (n > 0) {
                        val s = ((x - popLeft) / popIw).toInt().coerceIn(0, n - 1)
                        if (s != popupSel) {
                            popupSel = s
                            invalidate()
                        }
                    }
                    return
                }
                when (kr.key.type) {
                    KeyType.CHAR -> {
                        val nk = hit(x, y)
                        if (nk != null && nk !== kr && nk.key.type == KeyType.CHAR) {
                            kr.press.target = 0f
                            cancelLong(t)
                            t.kr = nk
                            pressKey(t, nk, x, y)
                        } else {
                            bubX.target = x
                            invalidate()
                        }
                    }
                    KeyType.DEL -> {
                        val dx = x - t.anchorX
                        if (dx < -dp(48f)) {
                            t.wordMode = true
                            cancelRepeat(t)
                            actions?.onBackspaceWord()
                            haptic()
                            t.anchorX = x
                        }
                    }
                    else -> {}
                }
            }
        }
    }

    private fun up(id: Int, x: Float, y: Float, cancel: Boolean) {
        val t = touches.get(id) ?: return
        touches.remove(id)
        cancelLong(t)
        cancelRepeat(t)
        when (t.region) {
            2 -> {
                val idx = if (cancel) -1 else pickerIndexAt(x, y)
                if (idx >= 0) {
                    if (idx != ModeState.index()) {
                        ModeState.set(idx)
                        onModeSwitched(x, barH())
                    }
                    closePicker()
                } else if (!t.opener || cancel) {
                    closePicker()
                }
            }
            1 -> {
                barPress.target = 0f
                if (!cancel && !t.done && !plain && abs(x - t.downX) < dp(14f)) {
                    switchMode(1, dp(25f), barH() / 2f)
                }
                invalidate()
            }
            0 -> {
                val kr = t.kr ?: return
                kr.press.target = 0f
                bubScale.target = 0f
                if (t.popup) {
                    popupOpen = false
                    if (!cancel && popupItems.isNotEmpty()) {
                        val s = popupItems[popupSel.coerceIn(0, popupItems.size - 1)]
                        consumeShift()
                        actions?.onKey(s)
                    }
                    invalidate()
                    return
                }
                if (!cancel) onKeyReleased(t, kr, x, y)
                invalidate()
            }
        }
    }

    private fun onKeyReleased(t: Touch, kr: KRect, x: Float, y: Float) {
        when (kr.key.type) {
            KeyType.CHAR -> {
                val s = display(kr)
                consumeShift()
                actions?.onKey(s)
            }
            KeyType.SPACE -> {
                val dx = x - t.downX
                val dy = y - t.downY
                if (dy < -dp(38f) && abs(dy) > abs(dx)) {
                    toggleLastMode(x, y)
                } else if (abs(dx) > dp(70f)) {
                    toggleLanguage()
                } else {
                    actions?.onSpace()
                }
            }
            KeyType.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                shift = when {
                    shift == 2 -> 0
                    shift == 1 && now - lastShiftTap < 350L -> 2
                    shift == 1 -> 0
                    else -> 1
                }
                lastShiftTap = now
                autoShift = false
            }
            KeyType.ENTER -> actions?.onEnter()
            KeyType.TO_SYM, KeyType.TO_SYM1 -> setPage(1)
            KeyType.TO_SYM2 -> setPage(2)
            KeyType.TO_ABC -> setPage(0)
            KeyType.LANG -> toggleLanguage()
            else -> {}
        }
    }

    private fun setPage(id: Int) {
        pageId = id
        buildLayout(true)
    }

    private fun toggleLanguage() {
        lang = 1 - lang
        Prefs.lang = lang
        pageId = 0
        buildLayout(true)
        actions?.onLanguageChanged()
    }

    private fun switchMode(delta: Int, x: Float, y: Float) {
        if (plain) return
        ModeState.step(delta)
        onModeSwitched(x, y)
    }

    private fun toggleLastMode(x: Float, y: Float) {
        if (plain) return
        ModeState.toggleLast()
        onModeSwitched(x, y)
    }

    private fun onModeSwitched(x: Float, y: Float) {
        accFrom = accentShown
        accTo = ModeState.current().accent
        accT.snap(0f)
        accT.target = 1f
        waveStart = System.nanoTime()
        waveX = x
        waveY = y
        haptic()
        actions?.onModeChanged()
        previewRendered = if (previewRaw.isEmpty()) "" else currentMode().render(previewRaw)
        invalidate()
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }
}
