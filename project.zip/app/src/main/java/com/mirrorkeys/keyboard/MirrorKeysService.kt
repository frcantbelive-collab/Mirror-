package com.mirrorkeys.keyboard

import android.content.SharedPreferences
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputConnection
import com.mirrorkeys.Prefs
import com.mirrorkeys.modes.InputMode
import com.mirrorkeys.modes.ModeState
import com.mirrorkeys.modes.NormalMode
import com.mirrorkeys.modes.Strategy

class MirrorKeysService : InputMethodService(), KeyboardActions {

    private var kv: KeyboardView? = null

    /** Сырой ввод: текущее слово (DIRECT/INSERT_BEFORE) или composing-буфер (WORD/PHRASE). */
    private val raw = StringBuilder()

    /** Что мы реально вставили (для корректного Backspace). */
    private val stack = ArrayList<String>()
    private var letterIndex = 0
    private var selStart = 0
    private var selEnd = 0
    private var plain = false
    private var composeMode: InputMode? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        kv?.applyPrefs()
    }

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        ModeState.load()
        Prefs.register(prefListener)
    }

    override fun onDestroy() {
        Prefs.unregister(prefListener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val v = KeyboardView(this)
        v.actions = this
        kv = v
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetBuffers()
        plain = computePlain(info)
        selStart = info?.initialSelStart ?: 0
        selEnd = info?.initialSelEnd ?: 0
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        val numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
        kv?.applyPrefs()
        kv?.setPlain(plain)
        kv?.setPageForInput(numeric)
        kv?.setPreview("")
        updateCaps()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        currentInputConnection?.finishComposingText()
        resetBuffers()
        super.onFinishInputView(finishingInput)
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        selStart = newSelStart
        selEnd = newSelEnd
        // пользователь сам передвинул курсор - composing-слово завершаем
        if (composeMode != null && raw.isNotEmpty() &&
            (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)
        ) {
            raw.setLength(0)
            composeMode = null
            currentInputConnection?.finishComposingText()
            kv?.setPreview("")
        }
    }

    // ───────────── вспомогательное ─────────────
    private fun computePlain(info: EditorInfo?): Boolean {
        if (info == null) return true
        val t = info.inputType
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return true
        val v = t and InputType.TYPE_MASK_VARIATION
        if (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            v == InputType.TYPE_TEXT_VARIATION_URI
        ) return true
        val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
        return action == EditorInfo.IME_ACTION_SEARCH
    }

    private fun mode(): InputMode = if (plain) NormalMode else ModeState.current()

    private fun isWordChar(c: Char): Boolean = c.isLetterOrDigit() || c == '\''

    private fun resetBuffers() {
        raw.setLength(0)
        stack.clear()
        letterIndex = 0
        composeMode = null
    }

    private fun sendDel() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    private fun updateCaps() {
        val v = kv ?: return
        val ei = currentInputEditorInfo
        val ic = currentInputConnection
        if (ei == null || ic == null || ei.inputType == 0) {
            v.setAutoShift(false)
            return
        }
        if (mode().strategy == Strategy.INSERT_BEFORE && stack.isNotEmpty()) {
            v.setAutoShift(false)
            return
        }
        val caps = ic.getCursorCapsMode(ei.inputType)
        v.setAutoShift(caps != 0)
    }

    private fun afterEdit() {
        updateCaps()
        kv?.setPreview(raw.toString())
    }

    /** Завершить composing-слово/фразу: заменить на преобразованный текст. */
    private fun commitPending() {
        val m = composeMode
        val ic = currentInputConnection
        if (m != null && ic != null && raw.isNotEmpty()) {
            val s = raw.toString()
            val core = s.trimEnd()
            val trail = s.substring(core.length)
            ic.commitText(m.transform(core) + trail, 1)
        }
        if (m != null) raw.setLength(0)
        composeMode = null
    }

    // ───────────── ввод ─────────────
    private fun put(text: String) {
        val ic = currentInputConnection ?: return
        if (text.isEmpty()) return
        val m = mode()
        val first = text[0]
        if (selStart != selEnd && m.strategy != Strategy.WORD && m.strategy != Strategy.PHRASE) {
            stack.clear()
        }
        when (m.strategy) {
            Strategy.DIRECT -> {
                commitPending()
                val out = m.mapChar(text, letterIndex)
                ic.commitText(out, 1)
                stack.add(out)
                if (stack.size > 400) stack.removeAt(0)
                if (first.isLetter()) letterIndex++
                trackRaw(text)
            }
            Strategy.INSERT_BEFORE -> {
                commitPending()
                val out = m.mapChar(text, 0)
                // newCursorPosition = 0: курсор остаётся ПЕРЕД вставленным текстом
                ic.commitText(out, 0)
                stack.add(out)
                trackRaw(text)
            }
            Strategy.WORD, Strategy.PHRASE -> {
                val brk = if (m.strategy == Strategy.WORD) !isWordChar(first) else ".!?\n".indexOf(first) >= 0
                if (brk) {
                    commitPending()
                    ic.commitText(text, 1)
                    raw.setLength(0)
                    stack.clear()
                } else {
                    raw.append(text)
                    composeMode = m
                    ic.setComposingText(m.transform(raw.toString()), 1)
                }
            }
        }
        afterEdit()
    }

    private fun trackRaw(text: String) {
        if (isWordChar(text[0])) raw.append(text) else raw.setLength(0)
    }

    override fun onKey(text: String) = put(text)

    override fun onSpace() = put(" ")

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        val m = mode()
        if (selStart != selEnd) {
            commitPending()
            sendDel()
            resetBuffers()
            afterEdit()
            return
        }
        when (m.strategy) {
            Strategy.DIRECT -> {
                if (stack.isNotEmpty()) {
                    val last = stack[stack.size - 1]
                    val before = ic.getTextBeforeCursor(last.length, 0)
                    if (before != null && before.toString() == last) {
                        ic.deleteSurroundingText(last.length, 0)
                        stack.removeAt(stack.size - 1)
                        if (raw.isNotEmpty()) raw.setLength(raw.length - 1)
                    } else {
                        stack.clear()
                        raw.setLength(0)
                        sendDel()
                    }
                } else {
                    sendDel()
                }
            }
            Strategy.INSERT_BEFORE -> {
                if (stack.isNotEmpty()) {
                    val last = stack[stack.size - 1]
                    val after = ic.getTextAfterCursor(last.length, 0)
                    if (after != null && after.toString() == last) {
                        // зеркало: последний набранный символ стоит справа от курсора
                        ic.deleteSurroundingText(0, last.length)
                        stack.removeAt(stack.size - 1)
                        if (raw.isNotEmpty()) raw.setLength(raw.length - 1)
                    } else {
                        stack.clear()
                        raw.setLength(0)
                        sendDel()
                    }
                } else {
                    sendDel()
                }
            }
            Strategy.WORD, Strategy.PHRASE -> {
                if (raw.isNotEmpty() && composeMode != null) {
                    raw.setLength(raw.length - 1)
                    if (raw.isEmpty()) {
                        ic.commitText("", 1)
                        composeMode = null
                    } else {
                        ic.setComposingText(m.transform(raw.toString()), 1)
                    }
                } else {
                    sendDel()
                }
            }
        }
        afterEdit()
    }

    override fun onBackspaceWord() {
        val ic = currentInputConnection ?: return
        commitPending()
        val before = ic.getTextBeforeCursor(64, 0)?.toString() ?: ""
        if (before.isEmpty()) {
            sendDel()
        } else {
            var i = before.length
            while (i > 0 && before[i - 1].isWhitespace()) i--
            while (i > 0 && !before[i - 1].isWhitespace()) i--
            ic.deleteSurroundingText(before.length - i, 0)
        }
        resetBuffers()
        afterEdit()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val m = mode()
        commitPending()
        if (m.strategy == Strategy.INSERT_BEFORE && stack.isNotEmpty()) moveRightOverChunk(ic)
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnter = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (ei != null && !noEnter &&
            action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        resetBuffers()
        afterEdit()
    }

    /** После Enter в режиме «зеркало» курсор нужно вынести за набранный кусок. */
    private fun moveRightOverChunk(ic: InputConnection) {
        val sb = StringBuilder()
        for (s in stack.asReversed()) sb.append(s)
        val chunk = sb.toString()
        // стек: самый новый символ стоит прямо справа от курсора
        val expected = StringBuilder()
        for (s in stack.asReversed()) expected.append(s)
        val after = ic.getTextAfterCursor(chunk.length, 0)?.toString()
        if (after != expected.toString()) return
        val ex = ic.getExtractedText(ExtractedTextRequest(), 0)
        if (ex != null) {
            val pos = ex.startOffset + ex.selectionStart + chunk.length
            ic.setSelection(pos, pos)
        } else {
            for (i in 0 until chunk.length) sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_RIGHT)
        }
    }

    override fun onModeChanged() {
        commitPending()
        raw.setLength(0)
        stack.clear()
        letterIndex = 0
        updateCaps()
        kv?.setPreview("")
    }

    override fun onLanguageChanged() {
        updateCaps()
    }
}
