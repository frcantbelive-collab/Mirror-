package com.mirrorkeys.keyboard

class KeyTheme(
    val name: String,
    val dark: Boolean,
    val bg1: Int,
    val bg2: Int,
    val key1: Int,
    val key2: Int,
    val sp1: Int,
    val sp2: Int,
    val text: Int,
    val dim: Int,
    val shadow: Int
)

private fun c(v: Long): Int = v.toInt()

object Themes {
    val all: List<KeyTheme> = listOf(
        KeyTheme(
            "Стекло светлое", false,
            c(0xFFE9EEF7), c(0xFFD3DCEE),
            c(0xFFFFFFFF), c(0xFFEFF3FA),
            c(0xFFDCE2F0), c(0xFFCBD3E6),
            c(0xFF1B2233), c(0xFF76819A), c(0xFF1B2A55)
        ),
        KeyTheme(
            "Стекло тёмное", true,
            c(0xFF1C2132), c(0xFF0F131E),
            c(0xFF3B4258), c(0xFF2C3246),
            c(0xFF272D3F), c(0xFF1E2333),
            c(0xFFF1F4FF), c(0xFF8C97B5), c(0xFF000000)
        ),
        KeyTheme(
            "AMOLED", true,
            c(0xFF000000), c(0xFF000000),
            c(0xFF1E1E21), c(0xFF151517),
            c(0xFF111113), c(0xFF0A0A0C),
            c(0xFFFFFFFF), c(0xFF7B7B85), c(0xFF000000)
        ),
        KeyTheme(
            "Неон", true,
            c(0xFF150B31), c(0xFF050314),
            c(0xFF2A1759), c(0xFF1C0F40),
            c(0xFF1B1040), c(0xFF120A2D),
            c(0xFFE8F4FF), c(0xFF9784E0), c(0xFF000000)
        )
    )

    fun get(i: Int): KeyTheme = all[i.coerceIn(0, all.size - 1)]
}
