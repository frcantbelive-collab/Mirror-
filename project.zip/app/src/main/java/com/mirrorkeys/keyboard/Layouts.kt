package com.mirrorkeys.keyboard

enum class KeyType { CHAR, GAP, SHIFT, DEL, SPACE, ENTER, TO_SYM, TO_ABC, TO_SYM2, TO_SYM1, LANG }

/** alts - варианты по долгому нажатию, первый показывается в углу клавиши. */
class Key(val type: KeyType, val label: String = "", val weight: Float = 1f, val alts: String = "")

class Page(val letters: Boolean, val rows: List<List<Key>>)

object Layouts {
    private fun ch(s: String, alts: String = ""): Key = Key(KeyType.CHAR, s, 1f, alts)

    private fun gap(w: Float): Key = Key(KeyType.GAP, "", w)

    private fun chars(s: String): List<Key> = s.map { ch(it.toString()) }

    private fun row(s: String, digits: Boolean, extra: Map<Char, String>): List<Key> {
        val out = ArrayList<Key>()
        for (i in s.indices) {
            val c = s[i]
            val d = if (digits && i < 10) "1234567890"[i].toString() else ""
            out.add(ch(c.toString(), d + (extra[c] ?: "")))
        }
        return out
    }

    private fun bottom(units: Float, abc: Boolean): List<Key> = listOf(
        Key(if (abc) KeyType.TO_ABC else KeyType.TO_SYM, "", 1.5f),
        Key(KeyType.LANG, "", 1.2f),
        ch(",", "@#"),
        Key(KeyType.SPACE, "", units - 6.2f),
        ch(".", "!?:;-…"),
        Key(KeyType.ENTER, "", 1.5f)
    )

    private val ru: Page = Page(
        true,
        listOf(
            row("йцукенгшщзх", true, mapOf('е' to "ё")),
            row("фывапролджэ", false, emptyMap()),
            listOf(Key(KeyType.SHIFT, "", 1f)) +
                row("ячсмитьбю", false, mapOf('ь' to "ъ")) +
                listOf(Key(KeyType.DEL, "", 1f)),
            bottom(11f, false)
        )
    )

    private val en: Page = Page(
        true,
        listOf(
            row(
                "qwertyuiop", true,
                mapOf('e' to "èéêë", 'y' to "ý", 'u' to "üúùû", 'i' to "íìï", 'o' to "óòöô")
            ),
            listOf(gap(0.5f)) +
                row("asdfghjkl", false, mapOf('a' to "àáâäã", 's' to "ß")) +
                listOf(gap(0.5f)),
            listOf(Key(KeyType.SHIFT, "", 1.5f)) +
                row("zxcvbnm", false, mapOf('c' to "ç", 'n' to "ñ")) +
                listOf(Key(KeyType.DEL, "", 1.5f)),
            bottom(10f, false)
        )
    )

    private val sym1: Page = Page(
        false,
        listOf(
            chars("1234567890"),
            chars("@#₽_&-+()/"),
            listOf(Key(KeyType.TO_SYM2, "", 1.5f)) + chars("*\"':;!?") + listOf(Key(KeyType.DEL, "", 1.5f)),
            bottom(10f, true)
        )
    )

    private val sym2: Page = Page(
        false,
        listOf(
            chars("[]{}#%^*+="),
            chars("_\\|~<>€£¥•"),
            listOf(Key(KeyType.TO_SYM1, "", 1.5f)) + chars("…©®™°¿¡") + listOf(Key(KeyType.DEL, "", 1.5f)),
            bottom(10f, true)
        )
    )

    /** id: 0 буквы, 1 символы, 2 символы 2 */
    fun page(lang: Int, id: Int): Page = when (id) {
        1 -> sym1
        2 -> sym2
        else -> if (lang == 0) ru else en
    }
}
