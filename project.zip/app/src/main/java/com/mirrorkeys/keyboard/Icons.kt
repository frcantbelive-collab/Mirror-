package com.mirrorkeys.keyboard

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.mirrorkeys.modes.Fx
import com.mirrorkeys.modes.ModeIcon

/** Все иконки рисуются кодом - никаких файлов. */
object Icons {
    private val path = Path()
    private val rf = RectF()

    private fun stroke(p: Paint, color: Int, w: Float) {
        p.shader = null
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
    }

    fun drawShift(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint, filled: Boolean, color: Int) {
        path.reset()
        path.moveTo(cx, cy - s)
        path.lineTo(cx + s, cy)
        path.lineTo(cx + s * 0.45f, cy)
        path.lineTo(cx + s * 0.45f, cy + s * 0.9f)
        path.lineTo(cx - s * 0.45f, cy + s * 0.9f)
        path.lineTo(cx - s * 0.45f, cy)
        path.lineTo(cx - s, cy)
        path.close()
        stroke(p, color, s * 0.16f)
        if (filled) p.style = Paint.Style.FILL_AND_STROKE
        c.drawPath(path, p)
    }

    fun drawBackspace(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint, color: Int) {
        path.reset()
        path.moveTo(cx - s * 1.15f, cy)
        path.lineTo(cx - s * 0.45f, cy - s * 0.85f)
        path.lineTo(cx + s * 1.1f, cy - s * 0.85f)
        path.lineTo(cx + s * 1.1f, cy + s * 0.85f)
        path.lineTo(cx - s * 0.45f, cy + s * 0.85f)
        path.close()
        stroke(p, color, s * 0.16f)
        c.drawPath(path, p)
        c.drawLine(cx - s * 0.1f, cy - s * 0.35f, cx + s * 0.6f, cy + s * 0.35f, p)
        c.drawLine(cx + s * 0.6f, cy - s * 0.35f, cx - s * 0.1f, cy + s * 0.35f, p)
    }

    fun drawEnter(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint, color: Int) {
        path.reset()
        path.moveTo(cx + s * 0.9f, cy - s * 0.8f)
        path.lineTo(cx + s * 0.9f, cy + s * 0.2f)
        path.lineTo(cx - s * 0.8f, cy + s * 0.2f)
        path.moveTo(cx - s * 0.1f, cy - s * 0.5f)
        path.lineTo(cx - s * 0.8f, cy + s * 0.2f)
        path.lineTo(cx - s * 0.1f, cy + s * 0.9f)
        stroke(p, color, s * 0.18f)
        c.drawPath(path, p)
    }

    fun drawGlobe(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint, color: Int) {
        stroke(p, color, s * 0.13f)
        c.drawCircle(cx, cy, s, p)
        rf.set(cx - s * 0.45f, cy - s, cx + s * 0.45f, cy + s)
        c.drawOval(rf, p)
        c.drawLine(cx - s, cy, cx + s, cy, p)
        c.drawLine(cx - s * 0.87f, cy - s * 0.5f, cx + s * 0.87f, cy - s * 0.5f, p)
        c.drawLine(cx - s * 0.87f, cy + s * 0.5f, cx + s * 0.87f, cy + s * 0.5f, p)
    }

    /** Иконка режима: текст + эффект. p - любой Paint, его состояние сбрасывается. */
    fun drawModeIcon(c: Canvas, cx: Float, cy: Float, r: Float, icon: ModeIcon, color: Int, p: Paint) {
        p.shader = null
        p.color = color
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSkewX = 0f
        p.textSize = if (icon.text.length <= 1) r * 1.35f else r * 1.0f

        c.save()
        when (icon.fx) {
            Fx.ROT180 -> c.rotate(180f, cx, cy)
            Fx.FLIPX -> c.scale(-1f, 1f, cx, cy)
            Fx.ITALIC -> {
                p.textSkewX = -0.28f
                p.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
            }
            Fx.MONO -> p.typeface = Typeface.MONOSPACE
            else -> {}
        }
        val ty = cy - (p.descent() + p.ascent()) / 2f

        when (icon.fx) {
            Fx.ZIGZAG -> {
                stroke(p, color, r * 0.22f)
                path.reset()
                path.moveTo(cx - r * 0.9f, cy - r * 0.5f)
                path.lineTo(cx + r * 0.9f, cy - r * 0.5f)
                path.lineTo(cx - r * 0.9f, cy + r * 0.5f)
                path.lineTo(cx + r * 0.9f, cy + r * 0.5f)
                c.drawPath(path, p)
            }
            Fx.CIRCLE -> {
                c.drawText(icon.text, cx, ty, p)
                stroke(p, color, r * 0.16f)
                c.drawCircle(cx, cy, r * 1.05f, p)
            }
            Fx.DOUBLE -> {
                c.drawText(icon.text, cx - r * 0.09f, ty, p)
                c.drawText(icon.text, cx + r * 0.09f, ty, p)
            }
            else -> c.drawText(icon.text, cx, ty, p)
        }
        c.restore()

        p.style = Paint.Style.FILL
        p.textSkewX = 0f
        p.typeface = Typeface.DEFAULT
    }
}
