package com.mirrorkeys.keyboard

import kotlin.math.abs

/** Простая пружина (spring physics): value стремится к target. */
class Spring(
    var value: Float = 0f,
    var target: Float = 0f,
    private val k: Float = 420f,
    private val d: Float = 24f
) {
    var vel = 0f

    val active: Boolean
        get() = abs(target - value) > 0.0015f || abs(vel) > 0.02f

    fun step(dt: Float) {
        if (!active) {
            value = target
            vel = 0f
            return
        }
        var left = if (dt > 0.05f) 0.05f else dt
        while (left > 0f) {
            val h = if (left > 1f / 240f) 1f / 240f else left
            vel += (-k * (value - target) - d * vel) * h
            value += vel * h
            left -= h
        }
    }

    fun snap(v: Float) {
        value = v
        target = v
        vel = 0f
    }
}
