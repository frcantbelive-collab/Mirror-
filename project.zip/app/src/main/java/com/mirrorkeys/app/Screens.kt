package com.mirrorkeys.app

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.mirrorkeys.Prefs
import com.mirrorkeys.keyboard.KeyboardActions
import com.mirrorkeys.keyboard.KeyboardView
import com.mirrorkeys.keyboard.Themes
import com.mirrorkeys.modes.InputMode
import com.mirrorkeys.modes.ModeRegistry
import com.mirrorkeys.modes.ModeState

private val Bg = Color(0xFF0E1220)
private val CardC = Color(0xFF181E33)
private val Dim = Color(0xFF8C97B5)
private val Accent = Color(0xFF7C9CFF)

@Composable
fun MirrorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color(0xFF0B1020),
            background = Bg,
            surface = CardC,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

private fun isEnabled(ctx: Context): Boolean {
    val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    return imm.enabledInputMethodList.any { it.packageName == ctx.packageName }
}

private fun isSelected(ctx: Context): Boolean {
    val cur = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
    return cur != null && cur.startsWith(ctx.packageName)
}

@Composable
fun Root(tick: Int) {
    var onboarded by remember { mutableStateOf(Prefs.onboarded) }
    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        if (!onboarded) {
            Onboarding(tick) {
                Prefs.onboarded = true
                onboarded = true
            }
        } else {
            MainShell()
        }
    }
}

// ───────────── Онбординг ─────────────
@Composable
fun Orb(step: Int) {
    val c1 = when (step) {
        0 -> Color(0xFF22D3C5)
        1 -> Color(0xFFA66BFF)
        else -> Color(0xFFFF71CE)
    }
    val c2 = when (step) {
        0 -> Color(0xFF5B8CFF)
        1 -> Color(0xFFFF5FA2)
        else -> Color(0xFFFACC15)
    }
    Canvas(modifier = Modifier.size(190.dp)) {
        val r = size.minDimension / 2f
        drawCircle(
            brush = Brush.radialGradient(listOf(c1.copy(alpha = 0.55f), c2.copy(alpha = 0f))),
            radius = r
        )
        drawCircle(
            brush = Brush.linearGradient(
                listOf(c1, c2),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height)
            ),
            radius = r * 0.5f
        )
        drawCircle(color = Color.White.copy(alpha = 0.25f), radius = r * 0.32f, center = Offset(r * 0.85f, r * 0.8f))
    }
}

@Composable
fun BigButton(text: String, primary: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    if (primary) {
        Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp), shape = shape) {
            Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
    } else {
        OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp), shape = shape) {
            Text(text, fontSize = 16.sp)
        }
    }
}

@Composable
fun Onboarding(tick: Int, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var step by remember { mutableIntStateOf(0) }
    val enabled = remember(tick) { isEnabled(ctx) }
    val selected = remember(tick) { isSelected(ctx) }
    var test by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Orb(step)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0..2) {
                Box(
                    Modifier
                        .size(if (i == step) 22.dp else 8.dp, 8.dp)
                        .clip(CircleShape)
                        .background(if (i == step) Accent else Color(0xFF39425F))
                )
            }
        }
        Spacer(Modifier.height(20.dp))

        Crossfade(targetState = step, modifier = Modifier.weight(1f)) { s ->
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (s) {
                    0 -> {
                        Text("Включите MirrorKeys", fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Откройте список клавиатур и включите переключатель MirrorKeys.",
                            color = Dim, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(if (enabled) "✓ Клавиатура включена" else "Пока не включена", color = if (enabled) Color(0xFF4ADE80) else Dim)
                    }
                    1 -> {
                        Text("Выберите её основной", fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Нажмите кнопку ниже и в списке выберите MirrorKeys.",
                            color = Dim, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(if (selected) "✓ MirrorKeys выбрана" else "Пока не выбрана", color = if (selected) Color(0xFF4ADE80) else Dim)
                    }
                    else -> {
                        Text("Попробуйте!", fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Нажмите на поле. Короткий тап по кружку над клавишами меняет режим, долгое нажатие открывает все режимы.",
                            color = Dim, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(
                            value = test,
                            onValueChange = { test = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Тестовое поле") }
                        )
                    }
                }
            }
        }

        when (step) {
            0 -> {
                BigButton("Открыть настройки клавиатур") {
                    ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                }
                Spacer(Modifier.height(10.dp))
                BigButton("Далее", primary = false) { step = 1 }
            }
            1 -> {
                BigButton("Выбрать клавиатуру") {
                    val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.showInputMethodPicker()
                }
                Spacer(Modifier.height(10.dp))
                BigButton("Далее", primary = false) { step = 2 }
            }
            else -> {
                BigButton("Готово", onClick = onDone)
            }
        }
    }
}

// ───────────── Основное приложение ─────────────
@Composable
fun MainShell() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = CardC) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("Aa", fontWeight = FontWeight.Bold) },
                    label = { Text("Клавиатура") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("Zz", fontWeight = FontWeight.Bold) },
                    label = { Text("Лаборатория") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) Home() else Lab()
        }
    }
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    var typed by remember { mutableStateOf("") }
    var modeTick by remember { mutableIntStateOf(0) }
    var theme by remember { mutableIntStateOf(Prefs.theme) }
    var height by remember { mutableFloatStateOf(Prefs.heightPct.toFloat()) }
    var corner by remember { mutableFloatStateOf(Prefs.cornerPct.toFloat()) }
    var kvRef by remember { mutableStateOf<KeyboardView?>(null) }

    val actions = remember {
        object : KeyboardActions {
            override fun onKey(text: String) { typed += text }
            override fun onSpace() { typed += " " }
            override fun onBackspace() { if (typed.isNotEmpty()) typed = typed.dropLast(1) }
            override fun onBackspaceWord() {
                val s = typed.trimEnd()
                val i = s.lastIndexOf(' ')
                typed = if (i < 0) "" else s.substring(0, i + 1)
            }
            override fun onEnter() { typed += "\n" }
            override fun onModeChanged() { modeTick++ }
            override fun onLanguageChanged() {}
        }
    }

    val shown = remember(typed, modeTick) { ModeState.current().render(typed) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Text("MirrorKeys", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Живой предпросмотр. Печатайте прямо здесь.", color = Dim)
        Spacer(Modifier.height(12.dp))

        Box(
            Modifier.fillMaxWidth().height(96.dp).clip(RoundedCornerShape(20.dp)).background(CardC).padding(14.dp)
        ) {
            Text(
                if (shown.isEmpty()) "Результат появится здесь…" else shown,
                color = if (shown.isEmpty()) Dim else Color.White,
                fontSize = 18.sp
            )
        }
        Spacer(Modifier.height(12.dp))

        AndroidView(
            factory = { c ->
                KeyboardView(c).also {
                    it.actions = actions
                    kvRef = it
                }
            },
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
        )

        Spacer(Modifier.height(18.dp))
        Text("Тема", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Themes.all.forEachIndexed { i, t ->
                Box(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(t.key1))
                        .border(
                            width = if (i == theme) 3.dp else 1.dp,
                            color = if (i == theme) Accent else Color(0xFF39425F),
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            theme = i
                            Prefs.theme = i
                            kvRef?.applyPrefs()
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(t.name, color = Color(t.text), fontWeight = FontWeight.Medium)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Высота клавиш: ${height.toInt()}%")
        Slider(
            value = height,
            onValueChange = {
                height = it
                Prefs.heightPct = it.toInt()
                kvRef?.applyPrefs()
            },
            valueRange = 80f..120f
        )
        Text("Скругление: ${corner.toInt()}%")
        Slider(
            value = corner,
            onValueChange = {
                corner = it
                Prefs.cornerPct = it.toInt()
                kvRef?.applyPrefs()
            },
            valueRange = 0f..100f
        )

        Spacer(Modifier.height(8.dp))
        BigButton("Сменить клавиатуру", primary = false) {
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Lab() {
    var text by remember { mutableStateOf("Привет, MirrorKeys! Hello 123") }
    var zal by remember { mutableFloatStateOf(Prefs.zalgo.toFloat()) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("Лаборатория текста", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Один текст во всех режимах сразу.", color = Dim)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Введите текст") }
        )
        Text("Сила глитча: ${zal.toInt()}", color = Dim)
        Slider(
            value = zal,
            onValueChange = {
                zal = it
                Prefs.zalgo = it.toInt()
            },
            valueRange = 1f..8f,
            steps = 6
        )
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(ModeRegistry.all) { m ->
                ModeCard(m, text, zal.toInt())
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}

@Composable
fun ModeCard(m: InputMode, text: String, zalKey: Int) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val out = remember(text, zalKey) { m.render(text) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardC).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(Color(m.accent)))
            Spacer(Modifier.width(8.dp))
            Text(m.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            TextButton(onClick = {
                clip.setText(AnnotatedString(out))
                Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
            }) { Text("Копировать") }
        }
        Spacer(Modifier.height(4.dp))
        Text(out, fontSize = 17.sp)
    }
}
