package com.mirrorkeys.modes

import com.mirrorkeys.Prefs

/** Чтобы добавить режим: создать object : InputMode и дописать его сюда. */
object ModeRegistry {
    val all: List<InputMode> = listOf(
        NormalMode,
        MirrorMode,
        ReverseLettersMode,
        ReverseWordsMode,
        UpsideDownMode,
        FlipMode,
        VaporMode,
        BubbleMode,
        DoubleStruckMode,
        ScriptMode,
        MonoMode,
        ZalgoMode,
        TranslitMode,
        FixLayoutMode,
        CamelMode
    )
}

object ModeState {
    private var index = 0
    private var lastNonNormal = 1

    fun load() {
        val i = ModeRegistry.all.indexOfFirst { it.id == Prefs.modeId }
        index = if (i >= 0) i else 0
    }

    fun current(): InputMode = ModeRegistry.all[index]

    fun count(): Int = ModeRegistry.all.size

    fun index(): Int = index

    fun set(i: Int) {
        val n = count()
        val ni = ((i % n) + n) % n
        if (ni != index) {
            if (index != 0) lastNonNormal = index
            index = ni
            Prefs.modeId = current().id
        }
    }

    fun step(d: Int) = set(index + d)

    /** Быстрое вкл/выкл последнего режима. */
    fun toggleLast() {
        if (index != 0) {
            lastNonNormal = index
            set(0)
        } else {
            set(lastNonNormal)
        }
    }
}
