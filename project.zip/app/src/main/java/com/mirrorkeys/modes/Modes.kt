package com.mirrorkeys.modes

import com.mirrorkeys.Prefs

private fun col(v: Long): Int = v.toInt()

/** "ab cd" -> a->b, c->d (токены по 2 символа) */
private fun parsePairs(spec: String): Map<Char, Char> {
    val m = HashMap<Char, Char>()
    for (tok in spec.split(' ')) {
        if (tok.length == 2) m[tok[0]] = tok[1]
    }
    return m
}

/** "аa бb ёyo" -> а->"a", б->"b", ё->"yo" */
private fun parseStrings(spec: String): Map<Char, String> {
    val m = HashMap<Char, String>()
    for (tok in spec.split(' ')) {
        if (tok.length >= 2) m[tok[0]] = tok.substring(1)
    }
    return m
}

private fun cp(x: Int): String = String(Character.toChars(x))

// ───────────── 1. Обычный ─────────────
object NormalMode : InputMode {
    override val id = "normal"
    override val title = "Обычный"
    override val accent = col(0xFF5B8CFF)
    override val icon = ModeIcon("Aa")
    override val strategy = Strategy.DIRECT
}

// ───────────── 2. Зеркало ─────────────
object MirrorMode : InputMode {
    override val id = "mirror"
    override val title = "Зеркало"
    override val accent = col(0xFF22D3C5)
    override val icon = ModeIcon("pq")
    override val strategy = Strategy.INSERT_BEFORE
}

// ───────────── 3. Буквы наоборот внутри слова ─────────────
object ReverseLettersMode : InputMode {
    override val id = "rev_letters"
    override val title = "Буквы назад"
    override val accent = col(0xFFFF8A3D)
    override val icon = ModeIcon("ba")
    override val strategy = Strategy.WORD
    override fun transform(text: String): String = StringBuilder(text).reverse().toString()
}

// ───────────── 4. Слова в обратном порядке ─────────────
object ReverseWordsMode : InputMode {
    override val id = "rev_words"
    override val title = "Слова назад"
    override val accent = col(0xFFFFC53D)
    override val icon = ModeIcon("2 1")
    override val strategy = Strategy.PHRASE
    override fun transform(text: String): String = text.split(" ").reversed().joinToString(" ")
}

// ───────────── 5. Вверх ногами ─────────────
object UpsideDownMode : InputMode {
    override val id = "upside"
    override val title = "Вверх ногами"
    override val accent = col(0xFFA66BFF)
    override val icon = ModeIcon("A", Fx.ROT180)
    override val strategy = Strategy.INSERT_BEFORE

    private val map = parsePairs(
        "aɐ bq cɔ dp eǝ fɟ gƃ hɥ iᴉ jɾ kʞ ll mɯ nu oo pd qb rɹ ss tʇ un vʌ wʍ xx yʎ zz " +
            "A∀ Bᗺ CƆ Dᗡ EƎ FℲ G⅁ HH II Jſ K⋊ L⅂ MW NN OO PԀ QΌ Rᴚ SS T⊥ U∩ VΛ WM XX Y⅄ ZZ " +
            "1Ɩ 2ᄅ 3Ɛ 4ㄣ 5ϛ 69 7ㄥ 88 96 00 " +
            ".˙ ,' '," + " !¡ ?¿ () )( [] ][ {} }{ <> >< _‾ &⅋ " +
            "аɐ вʚ гɹ еǝ кʞ мw пu тʇ уʎ"
    )

    override fun mapChar(ch: String, index: Int): String {
        if (ch.length != 1) return ch
        return map[ch[0]]?.toString() ?: ch
    }
}

// ───────────── 6. Зеркальные символы ─────────────
object FlipMode : InputMode {
    override val id = "flip"
    override val title = "Отражение"
    override val accent = col(0xFFFF5FA2)
    override val icon = ModeIcon("R", Fx.FLIPX)
    override val strategy = Strategy.INSERT_BEFORE

    private val map = parsePairs(
        "aɒ bd cɔ db eɘ gϱ nи pq qp rɿ sƨ zƹ " +
            "Bᗺ CƆ Dᗡ EƎ L⅃ NИ QϘ RЯ SƧ ZƸ " +
            "3Ɛ () )( [] ][ {} }{ <> >< " +
            "яr"
    )

    override fun mapChar(ch: String, index: Int): String {
        if (ch.length != 1) return ch
        return map[ch[0]]?.toString() ?: ch
    }
}

// ───────────── 7. Вапорвейв ─────────────
object VaporMode : InputMode {
    override val id = "vapor"
    override val title = "Вапорвейв"
    override val accent = col(0xFFFF71CE)
    override val icon = ModeIcon("V A")
    override val strategy = Strategy.DIRECT

    override fun mapChar(ch: String, index: Int): String {
        if (ch.isEmpty()) return ch
        if (ch == " ") return "   "
        val c = ch[0]
        val base = if (c in '!'..'~') (c.code + 0xFEE0).toChar().toString() else ch
        return "$base "
    }
}

// ───────────── 8. Unicode-шрифты ─────────────
abstract class FontMode : InputMode {
    override val strategy = Strategy.DIRECT

    abstract fun style(c: Char): String?

    override fun mapChar(ch: String, index: Int): String {
        if (ch.length != 1) return ch
        return style(ch[0]) ?: ch
    }

    protected fun styled(c: Char, up: Int, low: Int, dig: Int): String? {
        return when (c) {
            in 'A'..'Z' -> if (up < 0) null else cp(up + (c - 'A'))
            in 'a'..'z' -> if (low < 0) null else cp(low + (c - 'a'))
            in '0'..'9' -> if (dig < 0) null else cp(dig + (c - '0'))
            else -> null
        }
    }
}

object BubbleMode : FontMode() {
    override val id = "bubble"
    override val title = "Пузыри"
    override val accent = col(0xFF4ADE80)
    override val icon = ModeIcon("B", Fx.CIRCLE)

    override fun style(c: Char): String? {
        return when (c) {
            in '1'..'9' -> cp(0x2460 + (c - '1'))
            '0' -> "\u24EA"
            else -> styled(c, 0x24B6, 0x24D0, -1)
        }
    }
}

object DoubleStruckMode : FontMode() {
    override val id = "double"
    override val title = "Двойной"
    override val accent = col(0xFF60A5FA)
    override val icon = ModeIcon("D", Fx.DOUBLE)

    override fun style(c: Char): String? {
        return when (c) {
            'C' -> "\u2102"
            'H' -> "\u210D"
            'N' -> "\u2115"
            'P' -> "\u2119"
            'Q' -> "\u211A"
            'R' -> "\u211D"
            'Z' -> "\u2124"
            else -> styled(c, 0x1D538, 0x1D552, 0x1D7D8)
        }
    }
}

object ScriptMode : FontMode() {
    override val id = "script"
    override val title = "Курсив"
    override val accent = col(0xFFF472B6)
    override val icon = ModeIcon("S", Fx.ITALIC)

    override fun style(c: Char): String? = styled(c, 0x1D4D0, 0x1D4EA, -1)
}

object MonoMode : FontMode() {
    override val id = "mono"
    override val title = "Моно"
    override val accent = col(0xFF94A3B8)
    override val icon = ModeIcon("M", Fx.MONO)

    override fun style(c: Char): String? = styled(c, 0x1D670, 0x1D68A, 0x1D7F6)
}

// ───────────── 9. Zalgo ─────────────
object ZalgoMode : InputMode {
    override val id = "zalgo"
    override val title = "Глитч"
    override val accent = col(0xFFEF4444)
    override val icon = ModeIcon("Z", Fx.ZIGZAG)
    override val strategy = Strategy.DIRECT

    override fun mapChar(ch: String, index: Int): String {
        if (ch.isEmpty() || !ch[0].isLetterOrDigit()) return ch
        val strength = Prefs.zalgo.coerceIn(1, 8)
        val r = java.util.Random(ch[0].code * 7919L + index * 104729L)
        val sb = StringBuilder(ch)
        for (i in 0 until strength * 2) {
            sb.append((0x0300 + r.nextInt(0x70)).toChar())
        }
        return sb.toString()
    }
}

// ───────────── 10a. Транслит RU↔EN ─────────────
object TranslitMode : InputMode {
    override val id = "translit"
    override val title = "Транслит"
    override val accent = col(0xFF38BDF8)
    override val icon = ModeIcon("Я R")
    override val strategy = Strategy.DIRECT

    private val ruLat = parseStrings(
        "аa бb вv гg дd еe ёyo жzh зz иi йy кk лl мm нn оo пp рr сs тt уu фf хkh цts чch шsh щshch ъ' ыy ь' эe юyu яya"
    )
    private val latRu = parseStrings(
        "aа bб cц dд eе fф gг hх iи jй kк lл mм nн oо pп qк rр sс tт uу vв wв xкс yы zз"
    )

    override fun mapChar(ch: String, index: Int): String {
        if (ch.length != 1) return ch
        val c = ch[0]
        val lower = c.lowercaseChar()
        val dst = ruLat[lower] ?: latRu[lower] ?: return ch
        return if (c.isUpperCase()) dst.replaceFirstChar { it.uppercaseChar() } else dst
    }
}

// ───────────── 10b. Исправление раскладки ─────────────
object FixLayoutMode : InputMode {
    override val id = "fixlayout"
    override val title = "Раскладка"
    override val accent = col(0xFF34D399)
    override val icon = ModeIcon("йq")
    override val strategy = Strategy.DIRECT

    private val latToRu = parsePairs(
        "qй wц eу rк tе yн uг iш oщ pз aф sы dв fа gп hр jо kл lд zя xч cс vм bи nт mь `ё"
    )
    private val ruToLat: Map<Char, Char> = HashMap<Char, Char>().also { m ->
        for ((k, v) in latToRu) m[v] = k
        m['х'] = '['
        m['ъ'] = ']'
        m['ж'] = ';'
        m['э'] = '\''
        m['б'] = ','
        m['ю'] = '.'
    }

    override fun mapChar(ch: String, index: Int): String {
        if (ch.length != 1) return ch
        val c = ch[0]
        val lower = c.lowercaseChar()
        val dst = latToRu[lower] ?: ruToLat[lower] ?: return ch
        return if (c.isUpperCase()) dst.uppercaseChar().toString() else dst.toString()
    }
}

// ───────────── 11. СлИтНыЙ cAmEl ─────────────
object CamelMode : InputMode {
    override val id = "camel"
    override val title = "ЧеРеДуЙ"
    override val accent = col(0xFFFACC15)
    override val icon = ModeIcon("aB")
    override val strategy = Strategy.DIRECT

    override fun mapChar(ch: String, index: Int): String {
        if (ch.isEmpty() || !ch[0].isLetter()) return ch
        return if (index % 2 == 0) ch.uppercase() else ch.lowercase()
    }
}
