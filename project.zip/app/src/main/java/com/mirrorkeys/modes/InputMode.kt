package com.mirrorkeys.modes

enum class Strategy { DIRECT, INSERT_BEFORE, WORD, PHRASE }

enum class Fx { NONE, ROT180, FLIPX, CIRCLE, DOUBLE, ITALIC, MONO, ZIGZAG }

class ModeIcon(val text: String, val fx: Fx = Fx.NONE)

/**
 * Режим трансформации ввода.
 * DIRECT        - каждый символ преобразуется и вставляется сразу (mapChar)
 * INSERT_BEFORE - каждый символ вставляется ПЕРЕД предыдущими (зеркало), mapChar применяется к символу
 * WORD          - слово набирается как composing-текст и преобразуется целиком (transform)
 * PHRASE        - то же для всей фразы до . ! ? или Enter
 */
interface InputMode {
    val id: String
    val title: String
    val accent: Int
    val icon: ModeIcon
    val strategy: Strategy

    fun mapChar(ch: String, index: Int): String = ch

    fun transform(text: String): String = text

    /** Как выглядит текст целиком в этом режиме (для превью и Лаборатории). */
    fun render(text: String): String {
        return when (strategy) {
            Strategy.DIRECT -> {
                val sb = StringBuilder()
                var i = 0
                for (c in text) {
                    sb.append(mapChar(c.toString(), i))
                    if (c.isLetter()) i++
                }
                sb.toString()
            }
            Strategy.INSERT_BEFORE -> {
                val sb = StringBuilder()
                for (idx in text.length - 1 downTo 0) {
                    sb.append(mapChar(text[idx].toString(), 0))
                }
                sb.toString()
            }
            else -> transform(text)
        }
    }
}
