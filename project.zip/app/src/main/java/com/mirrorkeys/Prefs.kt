package com.mirrorkeys

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        if (sp == null) {
            sp = ctx.applicationContext.getSharedPreferences("mirrorkeys", Context.MODE_PRIVATE)
        }
    }

    private fun s(): SharedPreferences = sp ?: throw IllegalStateException("Prefs not initialised")

    var theme: Int
        get() = s().getInt("theme", 0)
        set(v) { s().edit().putInt("theme", v).apply() }

    var lang: Int
        get() = s().getInt("lang", 0)
        set(v) { s().edit().putInt("lang", v).apply() }

    var modeId: String
        get() = s().getString("mode", "normal") ?: "normal"
        set(v) { s().edit().putString("mode", v).apply() }

    var zalgo: Int
        get() = s().getInt("zalgo", 3)
        set(v) { s().edit().putInt("zalgo", v).apply() }

    var heightPct: Int
        get() = s().getInt("heightPct", 100)
        set(v) { s().edit().putInt("heightPct", v).apply() }

    var cornerPct: Int
        get() = s().getInt("cornerPct", 50)
        set(v) { s().edit().putInt("cornerPct", v).apply() }

    var onboarded: Boolean
        get() = s().getBoolean("onboarded", false)
        set(v) { s().edit().putBoolean("onboarded", v).apply() }

    fun register(l: SharedPreferences.OnSharedPreferenceChangeListener) {
        s().registerOnSharedPreferenceChangeListener(l)
    }

    fun unregister(l: SharedPreferences.OnSharedPreferenceChangeListener) {
        s().unregisterOnSharedPreferenceChangeListener(l)
    }
}
