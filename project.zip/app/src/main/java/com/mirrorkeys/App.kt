package com.mirrorkeys

import android.app.Application
import com.mirrorkeys.modes.ModeState

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        ModeState.load()
    }
}
